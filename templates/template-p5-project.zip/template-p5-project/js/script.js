function setup() {
  background(255, 0, 0);
}

function draw() {

}