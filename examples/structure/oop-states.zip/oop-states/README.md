An example of representing your program's states using **Object-Oriented Programming** with **inheritance** and **polymorphism**. Reworks an earlier example of a simulation with a title, simulation, and ending. Probably the ideal way to represent your states.

[Running program](https//pippinbarr.github.io/cart253-2020/examples/structure/oop-states/) / [Source Code](https://github.com/pippinbarr/cart253-2020/tree/master/examples/structure/oop-states) / [Download](https//pippinbarr.github.io/cart253-2020/examples/structure/oop-states.zip)
