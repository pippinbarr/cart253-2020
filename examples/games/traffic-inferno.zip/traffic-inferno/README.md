# Traffic Inferno

A terrifying traffic game in which you drive your pretty little cyan car around the dangerous non-streets of a black night and try not to collide with the flaming wrecks of others.

Control your car with the arrow keys. UP = accelerate. LEFT and RIGHT = turn.

Keep moving to increase your score, stop and it will decrease. Try to set a high score I guess?

[Run the program](https://pippinbarr.github.io/cart253-2020/examples/games/traffic-inferno/) | [Source Code](https://www.github.com/pippinbarr/cart253-2020/tree/master/examples/games/traffic-inferno/) | [Download Source](https://pippinbarr.github.io/cart253-2020/examples/games/traffic-inferno.zip)
