# Typewriter effect

A class that mimics a typewriter for displaying a specified text. With a simple example script showing a basic usage. Could be more complicated, but just tries to show the basic idea.

[Running program](https://pippinbarr.github.io/cart253-2020/examples/text/typewriter-effect/) / [Source Code](https://github.com/pippinbarr/cart253-2020/tree/master/examples/text/typewriter-effect) / [Download](https//pippinbarr.github.io/cart253-2020/examples/text/typewriter-effect.zip)
