# Typewriter effect

A class that mimics a typewriter for displaying a specified text. With a simple example script showing a basic usage. Could be more complicated, but just tries to show the basic idea.
