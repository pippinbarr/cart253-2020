# Magic Word

A small example of requiring the user to using typing in a specific word as a form of input. It lets the user type characters and displays them, and compares their typed input to a magic word that solves the incredibly smart riddle.

[Running program](https://pippinbarr.github.io/cart253-2020/examples/text/magic-word/) / [Source Code](https://github.com/pippinbarr/cart253-2020/tree/master/examples/text/magic-word) / [Download](https//pippinbarr.github.io/cart253-2020/examples/text/magic-word.zip)
