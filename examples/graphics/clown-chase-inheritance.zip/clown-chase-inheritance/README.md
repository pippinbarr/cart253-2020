# Clown Chase

An example of combining **images** with **JavaScript Objects**. Two objects represented as different clown face images. The user controls one with the keyboard and the other one chases the user.

[Running program](https//pippinbarr.github.io/cart253-2020/examples/graphics/clown-chase/) / [Source Code](https://github.com/pippinbarr/cart253-2020/tree/master/examples/graphics/clown-chase) / [Download](https//pippinbarr.github.io/cart253-2020/examples/graphics/clown-chase.zip)
